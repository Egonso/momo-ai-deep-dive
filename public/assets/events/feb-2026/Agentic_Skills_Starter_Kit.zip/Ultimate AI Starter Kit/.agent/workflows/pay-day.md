---
description: Der "Pay Day" Workflow. Findet abgeschlossene Projekte und schreibt Rechnungen.
---

# 💸 Pay Day Workflow

Dieser Workflow sorgt dafür, dass nichts "unter den Tisch fällt". Er scannt deine Notizen nach abgeschlossenen Projekten und bereitet die Rechnungen vor.

// turbo
1. Suche im Ordner `Second Brain/Projects` nach Dateien, die den Status `#completed` haben aber noch nicht `#billed` sind.
2. Liste diese Projekte auf und frage den User: "Soll ich für diese Projekte Rechnungen erstellen?"
3. Für jedes bestätigte Projekt:
    - Extrahiere Kundenname und Projektwert aus der Datei.
    - Starte den Skill `create-invoice` mit diesen Daten.
    - Markiere das Projekt im `Second Brain` als `#billed`.
4. Erstelle eine Zusammenfassung: "Gesamtbetrag in Rechnungen gestellt: [Summe] €".
5. Frage, ob die Rechnungen direkt per Email-Entwurf vorbereitet werden sollen.

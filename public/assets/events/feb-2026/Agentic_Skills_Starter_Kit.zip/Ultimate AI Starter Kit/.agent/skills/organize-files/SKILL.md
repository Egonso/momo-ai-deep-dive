---
name: organize-files
description: Scannt einen Ordner (z.B. Downloads) und sortiert Dateien automatisch in eine logische Struktur basierend auf Dateityp und Inhalt.
---

# File Organizer Skill 🧹

## Was dieser Skill macht
Nie wieder Chaos im Downloads-Ordner. Dieser Skill analysiert Dateien, benennt sie bei Bedarf um (für bessere Lesbarkeit) und verschiebt sie in passende Unterordner.

## Wann du ihn nutzen solltest
- Wenn dein Desktop oder Downloads-Ordner überquillt.
- Einmal wöchentlich als "Housekeeping"-Routine.

## Anweisungen für den Agenten

1.  **Ziel-Ordner identifizieren**: Frage den User, welchen Ordner (z.B. `/Downloads`) er aufräumen will.
2.  **Scan**: Liste alle Dateien auf.
3.  **Kategorisierung**:
    - `Bilder`: .jpg, .png, .webp -> `/Media/Images`
    - `Dokumente`: .pdf, .docx, .txt -> `/Documents`
    - `Installer`: .dmg, .pkg, .zip -> `/Installers` (Frage ob löschen?)
4.  **Inhalts-Check (Smart Move)**:
    - Wenn eine PDF "Rechnung" oder "Invoice" im Namen oder Inhalt hat -> `/Finanzen/Rechnungen`.
    - Wenn eine Datei "Vertrag" heißt -> `/Rechtliches`.
5.  **Aktion**: Verschiebe die Dateien.
6.  **Bericht**: Gib eine kurze Zusammenfassung: "Habe 23 Dateien aufgeräumt. 5 Rechnungen erkannt."

## Sicherheit
- Lösche niemals Dateien ohne explizite Bestätigung.
- Überschreibe keine Dateien (benenne sie um bei Duplikaten).

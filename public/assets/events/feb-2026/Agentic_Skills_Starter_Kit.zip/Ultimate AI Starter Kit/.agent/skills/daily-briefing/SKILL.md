---
name: daily-briefing
description: Erstellt eine kompakte Zusammenfassung der wichtigsten Nachrichten, E-Mails und Termine für den Start in den Tag.
---

# Daily Briefing Skill

## Was dieser Skill macht
Dieser Skill ist dein persönlicher Nachrichten-Assistent. Er analysiert verschiedene Quellen, um dir einen schnellen Überblick zu geben, damit du informiert in den Tag startest, ohne von Informationen überflutet zu werden.

## Wann du ihn nutzen solltest
- Jeden Morgen zum Arbeitsbeginn.
- Wenn du nach einem halben Tag Pause schnell wieder "up to date" sein willst.

## Anweisungen für den Agenten

1.  **Datums-Check**: Prüfe das heutige Datum.
2.  **Kalender-Check**: Liste die Termine für heute auf (Priorisiere Konflikte).
3.  **Wichtige E-Mails**: Suche nach E-Mails von VIP-Kontakten oder mit Kennzeichnung "Dringend".
4.  **News-Scan**: (Optional) Suche nach Schlagzeilen zu definierten Interessen (z.B. "KI Trends", "Markt Updates").
5.  **Output**: Erstelle eine Markdown-Zusammenfassung im Ordner `Daily Briefings/YYYY-MM-DD.md`.
    - Format:
        - 📅 **Agenda**
        - 📧 **Inbox Zero Fokus** (Nur die 3 wichtigsten Mails)
        - 🌍 **Weltgeschehen** (3 Bullet Points)
        - 💡 **Motivation/Zitat des Tages**

## Tools
- `calendar_tool` (Simuliert)
- `email_tool` (Simuliert)
- `search_web`

---
name: create-invoice
description: Erstellt automatisch eine professionelle PDF-Rechnung, speichert sie ab und aktualisiert die Buchhaltung.
---

# Create Invoice Skill 💸

## Was dieser Skill macht
Dieser Skill verwandelt Projektdaten in fertige Rechnungen. Er nimmt Empfänger, Betrag und Leistung entgegen, generiert ein PDF (basierend auf deinem Template) und legt es sauber ab.

## Wann du ihn nutzen solltest
- Nach Abschluss eines Projekts.
- Am Monatsende für Retainer-Kunden.
- Wenn du "Geld verdienen" automatisieren willst.

## Anweisungen für den Agenten

1.  **Daten erfassen**:
    - Wenn nicht angegeben, frage nach: `Kunde`, `Leistung`, `Betrag (Netto)`.
    - (Optional) Prüfe `contacts.csv` nach der Adresse des Kunden.
2.  **Rechnungsnummer generieren**:
    - Prüfe den Ordner `/Finanzen/Rechnungen/YYYY` nach der letzten Nummer (z.B. `RE-2026-005`).
    - Nimm die nächste Nummer (`RE-2026-006`).
3.  **PDF Erstellung**:
    - Nutze das Template `invoice_template.md` (oder simuliere die PDF-Erstellung).
    - Fülle die Platzhalter.
    - Speichere als `RE-2026-XXX_Kunde.pdf`.
4.  **Ablage**:
    - Verschiebe das PDF nach `/Finanzen/Rechnungen/2026/`.
5.  **Tracking**:
    - Füge eine Zeile in `/Finanzen/Einnahmen_2026.csv` hinzu:
    - `Datum, Re-Nr, Kunde, Betrag, Status: Offen`

## Tools
- `file_search` (um die letzte Rechnungsnummer zu finden)
- `write_to_file` (um das PDF/Markdown zu erstellen)
- `append_to_file` (für das Tracking Sheet)

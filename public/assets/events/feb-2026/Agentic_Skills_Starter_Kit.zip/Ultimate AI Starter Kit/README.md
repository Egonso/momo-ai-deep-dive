# Agentic Skills Starter Kit 🚀

Willkommen in deinem neuen **AI-gesteuerten Arbeitsbereich**.
Dies ist das Fundament für deinen neuen digitalen Assistenten. Es ist ein "Living Document" - du wirst es mit der Zeit erweitern.

## 📂 Struktur

- **.agent/**: Das Herzstück. Hier leben deine "Skills" (Fähigkeiten) und "Workflows" (Abläufe).
    - **skills/**: Einzelne Fähigkeiten, die dein Agent gelernt hat.
    - **workflows/**: Schritt-für-Schritt Anleitungen für komplexe Aufgaben.
- **Second Brain/**: Dein Wissensspeicher. Hier legst du Notizen, Projekte und Dokumente ab.
- **Programmieren/**: Für deine Code-Projekte (auch wenn du Nicht-Coder bist – der Agent macht das hier).

## 🚀 Schnellstart

1.  Öffne diesen Ordner in **Antigravity** (oder deiner Agenten-Software, z.B. Cursor/VScode).
2.  Der Agent erkennt automatisch den `.agent` Ordner.
3.  Probiere es aus: "Erstelle eine Rechnung für das Projekt BrandLab".

## 🧠 Enthaltene Skills (Beta)

1.  **create-invoice**: Erstellt professionelle PDF-Rechnungen aus Projektdaten.
2.  **daily-briefing**: Fasst deine wichtigsten Updates zusammen.
3.  **organize-files**: Hält deinen digitalen Schreibtisch sauber.

## 🛠 Enthaltene Workflows

- **Pay Day**: Sucht nach abgeschlossenen Projekten und erstellt Rechnungen im Batch.

---
*Erstellt für den KI DeepDive Februar 2026. Version 1.0 (Foundation).*
